---
type: Curso
title: Disciplina Configuração e Mantenção de Software
tags: []
---

[Definição Configuração e Manutenção de Software](Pages/Defini%C3%A7%C3%A3o%20Configura%C3%A7%C3%A3o%20e%20Manuten%C3%A7%C3%A3o%20de%20Software.md)

