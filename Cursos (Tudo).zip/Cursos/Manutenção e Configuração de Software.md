---
type: Curso
title: Manutenção e Configuração de Software
tags: []
---

[Objetivo da disciplina](Pages/Objetivo%20da%20disciplina.md)

[Ferramentas de GCS](Pages/Ferramentas%20de%20GCS.md)

[Relacionamento do GCS e o Ciclo de Vida de Software](Pages/Relacionamento%20do%20GCS%20e%20o%20Ciclo%20de%20Vida%20de%20Software.md)

[GCS](Pages/GCS.md)

[Gerência de Mudanças de Software](Pages/Ger%C3%AAncia%20de%20Mudan%C3%A7as%20de%20Software.md)

[Controle de Versão de Código-Fonte](Pages/Controle%20de%20Vers%C3%A3o%20de%20C%C3%B3digo-Fonte.md)

/pa

