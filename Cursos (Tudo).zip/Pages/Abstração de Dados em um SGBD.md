---
type: Page
title: Abstração de Dados em um SGBD
description: null
icon: null
createdAt: '2025-08-25T22:36:03.157Z'
creationDate: 2025-08-25 19:36
modificationDate: 2025-08-25 19:47
tags: []
imagemDeCapa: null
---

- Nível Externo (Visão do Usuário)

    - Vião do Usuário

    - O que o usuário final enxerga: tabelas, colunas, consutas

- Nível Conceitual (Estrutura Lógica Global)

    - É a visão dos desenvolvedores/DBAs: como o banco está modelado de forma lógica

- Nível Interno (Armazenamento Físico)

    - É a visão do SGBD: como os dados estão gravados nos arquivos, índices, páginas de memória, blocos de disco


