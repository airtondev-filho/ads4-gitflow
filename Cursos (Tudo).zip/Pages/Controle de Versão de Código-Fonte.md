---
type: Page
title: Controle de Versão de Código-Fonte
description: null
icon: null
createdAt: '2025-08-26T22:54:37.403Z'
creationDate: 2025-08-26 19:54
modificationDate: 2025-08-26 20:23
tags: []
imagemDeCapa: null
---

**CONCEITO:**

- O controle de versão é uma disciplina de Gerência de Configuração de Software (GCS) que consiste no gerenciamento sistemático de todas as alterações feitas em artefatos de software (código-fonte, documentação, scripts, bibliotecas).



**SOMMERVILLE (2007)**

- Rastreabilidade: identificar que faz a mudança quando e por quê.

- Recuperação de versões: voltar a estados anteriores do sistema.

- Gerência de paralelismo: permitir que múltiplos desenvolvedores trabalhem em paralelo.

- Auditoria: Fornecer histórico detalhado para análise posterior.



***MODELOS PRINCIPAIS:***

*Centralizado e Distribuído*


CENTRALIZADO: onde um lugar só armazena tudo 

Exemplo: Subversion, CVS

- Todos os desenvolvedores interagem com um repositório central.

Vantagem:

- Simplicidade

Desvanteagem:

- Ponto único de falha e menor flexibilidade offline.


DISTRIBUÍDO: 

Exemplo: Git, Mercurial

- Cada desenvolvedor possui uma cópia completa do repositório.

Vantagem: 

- Vantegem: alta disponibilidade, trabalho offline, maior desempenho.

Desvantegem:

- Desvantagem: maior curva de aprendizado.



CONCLUSÃO: Controle de versão é uma ferramenta técnica que permite operacionalizar a gerência de mudanças, mas não a substitui.



COMPARAÇÃO:

Gerência de mudanças: fornece as políticas e processos (quem aprova, quando e porquê)

Controle de Versão: Fornece os mecanismos técnicos (como registrar, recuperar e auditar mudanças)



RESULTADO:

- Manutenível - fácil de evoluir;

- Confiável - mudanças não quebram funcionalidades antigas;

- Aditável - histórico claro de todas as alterações.





