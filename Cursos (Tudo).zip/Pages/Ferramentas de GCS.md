---
type: Page
title: Ferramentas de GCS
description: null
icon: null
createdAt: '2025-08-19T22:29:08.419Z'
creationDate: 2025-08-19 19:29
modificationDate: 2025-08-19 19:32
tags: []
imagemDeCapa: null
---

- Git: Controla verões do código fonte;

- Maven / npm / pip: garantem que todos usem as mesmas vesões de bibliotecas;

- Docker: garante que todos usem o mesmo ambiente (ex: mesma versão do banco de dados, mesmo servidor)

- Jenkins / GitHub Actions: automatizem testes e implementações

