---
type: Page
title: Gerência de Mudanças de Software
description: null
icon: null
createdAt: '2025-08-26T22:22:21.803Z'
creationDate: 2025-08-26 19:22
modificationDate: 2025-08-26 19:53
tags: []
imagemDeCapa: null
---

É UM PROCESSO ORGANIZACIONAL. NÃO É APENAS USAR FERRAMENTAS, MAS ADOTAR PROCEDIMENTOS NORMATIZADOS



É definida pela ISO/IBC como parte do processo de gerência de configuração

PROPÓSITO: assegurar que todos as mudanças em itens de software sejam avaliadas, aprovadas, implementadas e registradas  de maneira controlada.



SEGUNDO PRESSMAN (2006)

A mudança é inevitável no ciclo de vida do software, pois sistemas precisam evoluir em resposta a novas necessidades de negócios, mudanças tecnológicas e correções de defeitos. A gerência de mudanças busca equilibrar flexibilidade (responder rápido) com estabilidade (não comprometer a qualidade do sistema).



FLUXO DE GERÊNCIA DE MUDANÇAS:

1 -> Identificação da mudança - abertura de uma requisição de mudança (RFC).

2 -> Análise de impacto - avaliação de riscos, custos e benefícios.

3 -> Aprovação/rejeição - decisão formal por um comitê ou gestor responsável.

4 -> Implementação - desenvolvimento, testes e integração da mudança.

5 -> Validação - verificação se a mudança realmente resolve o problema sem gerar novos erros.

6 -> Registro e auditoria - documentação de alteração para rastreabilidade.



CLASSIFICAÇÃO DAS MUDANÇAS (ISO.IEC 14764)

. Corretiva - eliminar defeitos identificados.

. Adaptativa - adequar o sistema a novos ambientes ou plataformas.

. Perfectiva - melhor desempenho, usabilidade ou qualidade.

. Preventiva - reduzir risco de falhas futuras.

