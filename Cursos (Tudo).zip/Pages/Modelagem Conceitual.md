---
type: Page
title: Modelagem Conceitual
description: null
icon: null
createdAt: '2025-08-18T22:20:01.804Z'
creationDate: 2025-08-18 19:20
modificationDate: 2025-08-18 19:21
tags: []
imagemDeCapa: null
---

- É a visão mais abstrata e próxima do mundo real.

- Foco: o que existe no domínio (entidades, atributos e relacionamento)

- Não importa tamanho de campo, chaves primarias e tipo de dados.

