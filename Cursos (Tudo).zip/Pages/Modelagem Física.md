---
type: Page
title: Modelagem Física
description: null
icon: null
createdAt: '2025-08-18T22:30:06.045Z'
creationDate: 2025-08-18 19:30
modificationDate: 2025-08-18 19:32
tags: []
imagemDeCapa: null
---

- O que é: Implementação final no SGBD escolhido (PostgreSQL, MSQL, SQL Server etc.).

- Foco: Como os dados são armazenados de fato.

- Representação: Código SQL DDL (CREATE TABLE), índices, tipo de dados específicos, constraints, particionamento.

