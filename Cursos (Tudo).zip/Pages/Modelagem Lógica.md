---
type: Page
title: Modelagem Lógica
description: null
icon: null
createdAt: '2025-08-18T22:22:20.774Z'
creationDate: 2025-08-18 19:22
modificationDate: 2025-08-18 19:26
tags: []
imagemDeCapa: null
---

- O que é: Tradução deo medelo conceitual para estruturas mais próximas de tabelas;

- Foco: Como os dados vão se organizar no SGBD, mas de forma independente do sistema específico;

- Representação: Tabelas, Colunas, relacionamentos, chaves primárias e estrangeiras.

