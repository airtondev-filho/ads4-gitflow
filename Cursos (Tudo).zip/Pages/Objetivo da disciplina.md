---
type: Page
title: Objetivo da disciplina
description: null
icon: null
createdAt: '2025-08-19T22:17:25.018Z'
creationDate: 2025-08-19 19:17
modificationDate: 2025-08-19 19:28
tags: []
imagemDeCapa: null
---

- Controle de versão: Saber exatamente qual a versão de software utilizar;

- Rastreabilidade: Saber quando e quem fez alguma alteração no software (Logs);

- Consistência: Garantir que todas as partes dos sistema funcionem juntas, sem conflito de versões;

- Automação: Facilitar builds, testes e deplays automáticos

- Colaboração: Permitir que várias pessoas trabalhem  ao mesmo tempo sem prejudicar o trabalho da outra.

