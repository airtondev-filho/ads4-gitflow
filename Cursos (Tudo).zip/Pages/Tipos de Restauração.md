---
type: Page
title: Tipos de Restauração
description: null
icon: null
createdAt: '2025-09-08T22:46:38.300Z'
creationDate: 2025-09-08 19:46
modificationDate: 2025-09-08 19:49
tags: []
imagemDeCapa: null
---

- Restauração de backups lógicos: com pg_restore, recriando a estrutura e os dados.

- Recuperação física: substituindo os arquivos originais do banco pelos arquivos copiados.

- Point-in-time Recovery (PITR): permite restaurar o banco até um ponto exato no tempo, utilizando arquivos de log (WAL - Write Ahead Log).

